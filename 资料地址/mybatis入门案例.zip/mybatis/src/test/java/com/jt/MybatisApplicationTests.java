package com.jt;

import com.jt.mapper.UserMapper;
import com.jt.pojo.User;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

class MybatisApplicationTests {

    private SqlSessionFactory sqlSessionFactory;

    @BeforeEach
    public void init() throws IOException {
        /*创建SqlSessionFactory*/
        String resource = "mybatis/mybatis-config.xml";
        InputStream inputStream = Resources.getResourceAsStream(resource);
        sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
    }


    /*
    * Mysql入门实现步骤:
    *   1.编辑mybatis-config.xml核心配置文件
    *       1.1执行数据源配置
    *   2.编辑POJO实体对象.要求与数据库表中的字段一一对应
    *   3.编辑Mapper接口. 添加接口方法
    *   4.编辑接口的实现类(配置文件方式) 要求namespace id  resultType
    *   5.mybatis加载指定的mapper映射文件
    *   6.创建SqlSessionFactory工厂对象
    *   7.获取SqlSession,开启数据库链接
    *   8.获取接口对象(代理对象)
    *   9.调用接口方法,获取返回值结果
    *   10.关闭sqlSession链接.
    * */
    @Test
    public void testDemo1() throws IOException {

        /*创建SqlSessionFactory*/
        String resource = "mybatis/mybatis-config.xml";
        InputStream inputStream = Resources.getResourceAsStream(resource);
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);

        /*从SqlSessionFactory中获取sqlSession*/
        SqlSession sqlSession = sqlSessionFactory.openSession();

        /*获取mapper接口,执行接口方法*/
        UserMapper userMapper = sqlSession.getMapper(UserMapper.class);
        /*Mybatis为接口创建了一个代理对象
            知识点: 框架中通过接口调用方法时,如果没有实现类,则为其创建代理对象
                    代理对象~实现类
         */
        System.out.println(userMapper.getClass());
        List<User> userList = userMapper.findAll();
        System.out.println(userList);

        /*执行之后关闭SqlSession*/
        sqlSession.close();
    }

    @Test
    public void testDemo2() {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        UserMapper userMapper = sqlSession.getMapper(UserMapper.class);
        List<User> userList = userMapper.findAll();
        System.out.println(userList);
        sqlSession.close();
    }

    //知识扩展,利用namespace获取数据
    @Test
    public void testDemo3() {
        SqlSession sqlSession = sqlSessionFactory.openSession();
        List<User> userList = sqlSession.selectList("com.jt.mapper.UserMapper.findAll");
        System.out.println(userList);
        sqlSession.close();
    }

    @Test
    public void testUserById(){
        int id = 1;
        SqlSession sqlSession = sqlSessionFactory.openSession();
        UserMapper userMapper = sqlSession.getMapper(UserMapper.class);
        User user = userMapper.findUserById(id);
        System.out.println(user);
        sqlSession.close();
    }

    @Test
    public void testSaveUser(){
        User user = new User(null,"中秋节",2021,"女");
        SqlSession sqlSession = sqlSessionFactory.openSession();
        UserMapper userMapper = sqlSession.getMapper(UserMapper.class);
        int rows = userMapper.saveUser(user);
        if(rows > 0 ){
            System.out.println("事物提交");
            sqlSession.commit();
        }
        System.out.println(rows);
        sqlSession.close();
    }

    @Test
    public void testUpdateUser(){
        User user = new User(234,"中秋节BBBB",2021,"女");
        SqlSession sqlSession = sqlSessionFactory.openSession();
        UserMapper userMapper = sqlSession.getMapper(UserMapper.class);
        int rows = userMapper.updateUser(user);
        if(rows > 0 ){
            System.out.println("事物提交");
            sqlSession.commit();
        }
        System.out.println(rows);
        sqlSession.close();
    }

    @Test
    public void testDeleteUserById(){
        int id = 237;
        SqlSession sqlSession = sqlSessionFactory.openSession();
        UserMapper userMapper = sqlSession.getMapper(UserMapper.class);
        int rows = userMapper.deleteUserById(id);
        if(rows > 0 ){
            System.out.println("事物提交");
            sqlSession.commit();
        }
        System.out.println(rows);
        sqlSession.close();
    }

    /**
     * 查询age>=18 age<=100岁的用户
     */
    @Test
    public void testSelectUserListByAge(){
        SqlSession sqlSession = sqlSessionFactory.openSession();
        UserMapper userMapper = sqlSession.getMapper(UserMapper.class);
        Map map = new HashMap();
        map.put("minAge",18);
        map.put("maxAge",100);
        List<User> userList = userMapper.findUserListByAge(map);
        System.out.println(userList);
    }

    /**
     * 查询 name中包含'君'字的数据
     */
    @Test
    public void testSelectUserListByLike(){
        SqlSession sqlSession = sqlSessionFactory.openSession();
        UserMapper userMapper = sqlSession.getMapper(UserMapper.class);
        Map map = new HashMap();
        //map.put("name","君");
        map.put("name","%君%");
        List<User> userList = userMapper.selectUserListByLike(map);
        System.out.println(userList);
    }
}
