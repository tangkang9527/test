package com.jt.mapper;

import com.jt.pojo.User;

import java.util.List;
import java.util.Map;

public interface UserMapper {
    //查询所有的User列表信息
    List<User> findAll();
    User findUserById(Integer id);
    //实现数据新增
    int saveUser(User user);

    int updateUser(User user);

    int deleteUserById(Integer id);

    List<User> findUserListByAge(Map map);

    List<User> selectUserListByLike(Map map);
}
