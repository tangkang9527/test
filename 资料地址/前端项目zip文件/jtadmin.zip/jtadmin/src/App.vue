<template>
  <div id="app">
     <!-- <h3>我是默认访问的页面</h3> -->
      <!-- 添加路由占位符-->
      <router-view></router-view>
  </div>
</template>

<script>
  export default {
    name: "app"
  }
</script>

<style>

</style>
